# Automating point data extraction from multiple multi-band rasters
import rasterio
import csv
import os

input_dir = r"Predictor_Variables_Data\EVI"
output_dir = r"Predictor_Variables_Data\Extracted_Data\EVI"
csv_file = "Africa_5KM_Grid_v3_Coord.csv"

# read coordinates from CSV file, skipping the header row
with open(csv_file, "r") as f:
    reader = csv.reader(f)
    next(reader)  # skip header row
    coordinates = [(float(row[0]), float(row[1])) for row in reader]

# Loop over each raster file in the input directory
for filename in os.listdir(input_dir):
    if filename.endswith(".tif"):
        input_path = os.path.join(input_dir, filename)
        output_base = os.path.join(output_dir, os.path.splitext(filename)[0])

        # open input geotiff raster
        with rasterio.open(input_path) as src:
            # Loop over each band in the raster
            for band_number in range(0, src.count):
                print(f"Accessing Band {band_number} of {filename}")
                output_path = f"{output_base}_band_{band_number}.csv"

                # extract pixel values for each coordinate for the current band
                values = [x[band_number] for x in src.sample(coordinates)]

                # write extracted data to output CSV file
                with open(output_path, "w", newline="") as f:
                    writer = csv.writer(f)
                    writer.writerow(["lon", "lat", f"evi_band_{band_number}"])
                    for i, (lon, lat) in enumerate(coordinates):
                        writer.writerow([lon, lat, values[i]])
                print(f"Extracted: {filename}, Band {band_number}")

print("Extraction Finished")
