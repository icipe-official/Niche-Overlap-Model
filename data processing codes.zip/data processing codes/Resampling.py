# Downsampling geographic crs rasters.
import os
import rasterio
from rasterio.enums import Resampling


def resample_raster(input_path, output_path, target_resolution_km):
    with rasterio.open(input_path) as src:
        # Read the raster data
        data = src.read()

        # Get the original resolution
        original_resolution = (src.res[0], src.res[1])
        print(f"Original Resolution: {original_resolution}")

        # Convert target resolution from kilometers to degrees
        target_resolution_degrees = target_resolution_km / 111.32

        # Calculate the scaling factors for resampling
        scale_x = src.res[0] / target_resolution_degrees
        scale_y = src.res[1] / target_resolution_degrees

        # Resample the raster data
        resampled_data = src.read(
            out_shape=(src.count, int(src.height * scale_y), int(src.width * scale_x)),
            resampling=Resampling.average,  # statistical resampling method
        )

        # Update the metadata
        transform = src.transform * src.transform.scale(
            (src.width / resampled_data.shape[-1]),
            (src.height / resampled_data.shape[-2]),
        )

        profile = src.profile
        profile.update(
            {
                "height": resampled_data.shape[1],
                "width": resampled_data.shape[2],
                "transform": transform,
            }
        )

        # Write the resampled raster to the output file
        with rasterio.open(output_path, "w", **profile) as dst:
            dst.write(resampled_data)


input_folder = r"path"
output_folder = r"path"
target_resolution_km = 5  # KM

# Iterate over all files in the input folder
for filename in os.listdir(input_folder):
    if filename.endswith(".tif") or filename.endswith(".tiff"):
        print(f"Resampling {filename}")
        # Construct input and output file paths
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(output_folder, filename)
        resample_raster(input_path, output_path, target_resolution_km)
