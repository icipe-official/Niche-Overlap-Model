# Automating the clipping of multiple rasters using a single shapefile or vector

import os
import glob
from shapely.geometry import mapping
import rioxarray as rxr
import xarray as xr
import geopandas as gpd


# Input and output folders
input_folder = r"F:\PHD_Thesis\Vector_Atlas\database_of_datasets\2.Raster_Data\Climate_Weather_Data\Envidat_Data\CHELSA_5km\2023_Rasters\Prec\world"
output_folder = r"F:\PHD_Thesis\Vector_Atlas\database_of_datasets\2.Raster_Data\Climate_Weather_Data\Envidat_Data\CHELSA_5km\2023_Rasters\Prec\africa"

# Ensure the output folder exists
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

# Loading a Shapefile
shp = gpd.read_file(r"F:\PHD_Thesis\Vector_Atlas\database_of_datasets\1.Vector_Data\Africa_shp\Africa_shp\afr_g2014_2013_0.shp")

# Get a list of input files
input_files = glob.glob(os.path.join(input_folder, "*.tif"))

# Process each input file
for input_file in input_files:
    # Get the file name and extension
    file_name = os.path.basename(input_file)
    file_name_no_ext, file_ext = os.path.splitext(file_name)

    # Loading the raster
    raster = rxr.open_rasterio(input_file, masked=True).squeeze()

    # Write the CRS of the shapefile to the raster file
    raster.rio.write_crs(shp.crs, inplace=True)

    # Clipping/Cropping the raster according to the shapefile
    clipped_raster = raster.rio.clip(shp.geometry.apply(mapping), shp.crs)

    # Output file path
    output_file = os.path.join(output_folder, file_name)

    # Export the clipped raster as a tif file
    clipped_raster.rio.to_raster(output_file)

    print(f"Processed: {file_name}")

print("All files processed.")