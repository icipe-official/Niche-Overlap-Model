# Creating Geospatial Grids with Numpy, Shapely & Geopandas with a geographic CRS.

# Loading the required packages.
import geopandas as gpd
import numpy as np
from shapely.geometry import box

# Load the shapefile
# shapefile_path = "path_to_your_shapefile.shp"
# shp = gpd.read_file(shapefile_path)

# Calculate bounding box of the shapefile
xmin, ymin, xmax, ymax = aoi.total_bounds

# Define cell/pixel resolution in degrees
distance = 5  # In Kilometers
resolution = distance / 111.32  # 1 degree = 111.32km
cell_size = resolution  # Adjust as needed

# Generate grid
x = np.arange(xmin, xmax, cell_size)
y = np.arange(ymin, ymax, cell_size)
xx, yy = np.meshgrid(x, y)

# Convert grid to GeoDataFrame
polygons = [
    box(x, y, x + cell_size, y + cell_size) for x, y in zip(xx.ravel(), yy.ravel())
]
grid = gpd.GeoDataFrame(geometry=polygons, crs=aoi.crs)

# Get the grid cells that intersect the shapefile.
grid2 = gpd.sjoin(left_df=grid, right_df=aoi, how="inner")

# Plot the shapefile with the grids overlay
ax = aoi.plot(alpha=0.5)
grid.plot(ax=ax, color="red", alpha=0.5)
grid2.plot(ax=ax, color="green", alpha=0.5)
