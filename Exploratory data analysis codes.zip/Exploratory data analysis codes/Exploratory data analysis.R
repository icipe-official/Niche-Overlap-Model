
library(readxl)
species_data <- read_excel("C:/Users/eibrahim/Downloads/Eric_species_data.xlsx")
species_data <- data.frame(species_data)


# filtering the data
species_data$species.presence1<- ifelse(species_data$species %in% c('GAMBIAE COMPLEX','gambiae', 'gambiae (S)','coluzzii (gambiae M)', 
                                                                    'coluzzii (gambiae M)', 'gambiae (S/M)', 'Anopheles gambiae'), 1,
                                        ifelse(species_data$species %in% c('Anopheles funestus', 'funestus', 'FUNESTUS COMPLEX', 'Funestus Subgroup'), 2,
                                               ifelse(species_data$species %in% c('pharoensis', 'Anopheles pharoensis'), 3,
                                                      ifelse(species_data$species %in% c('coustani', 'COUSTANI COMPLEX'), 4, NA))))

species_data <- species_data[complete.cases(species_data$species.presence1),]
species_data_df <- data.frame(species_data)


#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@subseting data @@@@@@@@@@@@@@@@@@
selected_variables <- c('shrubs', 'build_up', 'temp_range',  'elevation', 'irrigation', 'ndvi',                              
  'relative_humidity', 'Climate_Moisture_Index', 'Cloud_Area_Fraction', 'Near_Surface_Wind_Speed',               
  'Potential_Evapotranspiration', 'Precipitation',  'Surface_Downwelling_Shortwave_Radiation',
  'species.presence1')

new_names <- c(
  'Shrubs',  'Built up', 'Temperature range', 'Elevation','Irrigation',  'NDVI',  'Relative_humidity',  
  'Climate moisture index', 'Cloud area fraction',  'Near surface wind Speed', 'Potential evapotranspiration',  
  'Precipitation',  'solar radiation','species presence')

# Subset data and rename columns
subset_df <- species_data_df[selected_variables]; names(subset_df) <- new_names


#####  Correlation analysis
library(metan)
correlation_analysis <- corr_coef(subset_df, method = "spearman")

plot(correlation_analysis, cex = 10.5,
     cex = 1.5, cex.axis = 1.5, 
     cex.lab = 1.3, cex.sub = 1.3)
par(cex.axis = 10.5)

############
# create subset of data;  
species_data_eda_gamb <- species_data_df[species_data_df$species.presence1 == "1", ]
species_data_eda_funes <- species_data_df[species_data_df$species.presence1 == "2", ]
species_data_eda_phar <- species_data_df[species_data_df$species.presence1 == "3", ]
species_data_eda_coust <- species_data_df[species_data_df$species.presence1 == "4", ]


summary(species_data_eda_gamb$Precipitation)
summary(species_data_eda_funes$Precipitation)
summary(species_data_eda_phar$Precipitation)
summary(species_data_eda_coust$Precipitation)


#####  Cluster analysis

#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@subseting data @@@@@@@@@@@@@@@@@@
selected_variables1 <- c(                            
  'shrubs',  'build_up',  'temp_range',  'elevation', 'irrigation',                             
  'ndvi', 'relative_humidity', 'Climate_Moisture_Index', 'Cloud_Area_Fraction',               
  'Near_Surface_Wind_Speed', 'Potential_Evapotranspiration',  'Precipitation',                         
  'Surface_Downwelling_Shortwave_Radiation')

new_names1 <- c( 
  'Shrubs',  'Built up', 'Temperature range',   'Elevation',    'Irrigation',  'NDVI',   'Relative_humidity',  
  'Climate moisture index', 'Cloud area fraction',  'Near surface wind Speed', 'Potential evapotranspiration',  
  'Precipitation',  'solar radiation')

# Subset data and rename columns
# Euclidean distance
dist <- dist(species_data_df, diag=TRUE)

subset_df1 <- species_data_df[selected_variables1]
names(subset_df1) <- new_names1

# Calculate the correlation matrix
cor_matrix <- cor(subset_df1,  method = "spearman")

# Set row names to variable names
rownames(cor_matrix) <- colnames(subset_df1)

# Perform hierarchical clustering
hc <- hclust(dist(cor_matrix))

# Create a dendrogram with variable names
plot(hc, main = "Dendrogram of Variables", xlab = "Variables", ylab = "Height", labels = colnames(subset_df1), 
     cex = 1.5,
     cex.axis = 1.5,
     cex.lab = 1.3,
     cex.sub = 1.3)


#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# create subset of data;  
species_data_eda_gamb <- subset_df[subset_df$`species presence` == "1", ]
species_data_eda_funes <- subset_df[subset_df$`species presence` == "2", ]
species_data_eda_phar <- subset_df[subset_df$`species presence` == "3", ]
species_data_eda_coust <- subset_df[subset_df$`species presence` == "4", ]

summary(species_data_eda_gamb$NDVI); summary(species_data_eda_funes$NDVI); summary(species_data_eda_phar$NDVI); summary(species_data_eda_coust$NDVI)
summary(species_data_eda_gamb$`Cloud area fraction`); summary(species_data_eda_funes$`Cloud area fraction`); summary(species_data_eda_phar$`Cloud area fraction`); summary(species_data_eda_coust$`Cloud area fraction`)
summary(species_data_eda_gamb$Precipitation); summary(species_data_eda_funes$Precipitation); summary(species_data_eda_phar$Precipitation); summary(species_data_eda_coust$Precipitation)
summary(species_data_eda_gamb$Irrigation); summary(species_data_eda_funes$Irrigation); summary(species_data_eda_phar$Irrigation); summary(species_data_eda_coust$Irrigation)
summary(species_data_eda_gamb$Elevation); summary(species_data_eda_funes$Elevation); summary(species_data_eda_phar$Elevation); summary(species_data_eda_coust$Elevation)
summary(species_data_eda_gamb$Shrubs); summary(species_data_eda_funes$Shrubs); summary(species_data_eda_phar$Shrubs); summary(species_data_eda_coust$Shrubs)
summary(species_data_eda_gamb$`Temperature range`); summary(species_data_eda_funes$`Temperature range`); summary(species_data_eda_phar$`Temperature range`); summary(species_data_eda_coust$`Temperature range`)
summary(species_data_eda_gamb$Relative_humidity); summary(species_data_eda_funes$Relative_humidity); summary(species_data_eda_phar$Relative_humidity); summary(species_data_eda_coust$Relative_humidity)
summary(species_data_eda_gamb$`Built up`); summary(species_data_eda_funes$`Built up`); summary(species_data_eda_phar$`Built up`); summary(species_data_eda_coust$`Built up`)

